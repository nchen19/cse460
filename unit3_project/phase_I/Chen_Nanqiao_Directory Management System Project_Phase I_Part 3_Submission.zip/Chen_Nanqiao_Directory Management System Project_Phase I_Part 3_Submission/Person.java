package cse460_unit3_project_part1;

public class Person {
	private String last;
	private String first;
	private String middle;


	public Person(String last, String first, String middle) {
		this.last = last;
		this.first = first;
		this.middle = middle;

	}

	public void printFirstName()
	{
	      System.out.print(first + " ");
	}
	public void printMiddleName()
	{
	      System.out.print(middle + " ");
	}
	public void printLastName()
	{
	      System.out.print(last+ " ");
	}

	
	public String getFirst(){
		return first;
	}

	public String getLast(){
		return last;
	}

	public String getMiddle(){
		return middle;
	}

}

